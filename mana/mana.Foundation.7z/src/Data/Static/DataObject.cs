namespace mana.Foundation
{
    public interface DataObject : ISerializable , ICacheable , IFormatString
    {
    }
}
