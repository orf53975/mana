namespace mana.Foundation
{
    public interface IFormatString
    {
        string ToFormatString(string nlIndent);
    }
}
