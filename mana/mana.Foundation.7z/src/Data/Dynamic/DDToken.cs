﻿namespace mana.Foundation
{
    public enum DDToken
    {
        ft_none = 0,
        ft_bool = 1,
        ft_byte,
        ft_int16,
        ft_int32,
        ft_int64,
        ft_intXU,
        ft_intX,
        ft_float,
        ft_float16,
        ft_str,
        ft_object
    }
}