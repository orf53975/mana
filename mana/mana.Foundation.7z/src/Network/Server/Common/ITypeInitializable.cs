﻿namespace mana.Foundation.Network.Server
{
    public interface ITypeInitializable
    {
    }
}