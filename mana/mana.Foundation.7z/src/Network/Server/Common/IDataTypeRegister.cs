﻿namespace mana.Foundation.Network.Server
{
    public interface IDataTypeRegister : ITypeInitializable
    {
        void RegistDataType();
    }
}
