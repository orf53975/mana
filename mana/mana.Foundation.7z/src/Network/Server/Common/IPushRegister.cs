﻿using System;

namespace mana.Foundation.Network.Server
{
    public interface IPushRegister : ITypeInitializable
    {
        void RegistPushMessage();
    }
}