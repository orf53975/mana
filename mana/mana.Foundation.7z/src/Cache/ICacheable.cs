﻿namespace mana.Foundation
{
    public interface ICacheable
    {
        void ReleaseToCache();
    }
}
